package com.ensa.gi4.datatabase;

import com.ensa.gi4.modele.Chaise;
import com.ensa.gi4.modele.Livre;
import com.ensa.gi4.modele.Materiel;

import java.util.ArrayList;
import java.util.List;

public class DataSource {

    public List<Materiel> materiels=new ArrayList<>();

   public List<Materiel> getMaterial(){


//
//
//
//     Materiel livre=new Livre();
//       livre.setName("the davinci code");
//   Materiel chaise=new Chaise();
//      chaise.setName("korsi");
//     materiels.add(livre);
//      materiels.add(chaise);
       for (int i = 0; i<materiels.size(); i++) {
           Materiel element = materiels.get(i);

           System.out.println("element numero "+" "+i+" "+element+"dont le nom est "+element.getName());
       }
//
//
      return materiels;
    }
}
