package com.ensa.gi4.service.api;

import com.ensa.gi4.modele.Materiel;

public interface GestionMaterielService {
    void init();
    void listerMateriel();
    void ajouterNouveauMateriel(Materiel materiel);
    void supprimermateriel(String name);
    void modifiermateriel(String name1,String name2);
    void locat() throws InterruptedException;
}
