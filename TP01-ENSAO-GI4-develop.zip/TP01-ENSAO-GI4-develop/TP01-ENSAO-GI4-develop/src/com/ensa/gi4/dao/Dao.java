package com.ensa.gi4.dao;

import com.ensa.gi4.datatabase.DataSource;
import com.ensa.gi4.modele.Materiel;

public interface Dao {

void listerMateriel();
void ajouterMateriel(Materiel materiel);
Materiel getMetriel(int id);
void supprimerMateriel(String name);
void modifierMateriel(String name1,String name2);
void allouerMateriel(String name) throws InterruptedException;



}
