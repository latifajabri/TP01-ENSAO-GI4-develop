package com.ensa.gi4.dao;

import com.ensa.gi4.datatabase.DataSource;
import com.ensa.gi4.modele.Materiel;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class DaoImp implements Dao{
DataSource dataSource;
public DaoImp(DataSource dataSource){
    this.dataSource=dataSource;
}

    @Override
    public void listerMateriel() {
        System.out.println("lister"+dataSource.getMaterial());

    }

    @Override
    public void ajouterMateriel(Materiel materiel) {
       dataSource.materiels.add(materiel);

    }

    @Override
    public Materiel getMetriel(int id) {
        return null;
    }

    @Override
    public void supprimerMateriel(String nameDao) {
    List<Materiel> materielList=dataSource.getMaterial();
        for (int i = 0; i<materielList.size(); i++) {
            Materiel element = materielList.get(i);
            if (element.getName().equals(nameDao)){
                dataSource.materiels.remove(element);
                System.out.println("ton materiel a ete supprimé  avec succée");


            }
        }


    }

    @Override
    public void modifierMateriel(String nameAncien,String nameNouveau) {

        List<Materiel> materielList=dataSource.getMaterial();
        for (int i = 0; i<materielList.size(); i++) {
            Materiel element = materielList.get(i);
            if (element.getName().equals(nameAncien)){
                element.setName(nameNouveau);
                System.out.println("le nom a ete modifié avec succé");




            }
        }

    }

   @Override
    public void allouerMateriel(String name) throws InterruptedException {

        Materiel materielA;
        for (Materiel materielss : dataSource.materiels) {
            if (materielss.getName().equals(name)) {
                materielA = materielss;
                dataSource.materiels.remove(materielA);
                System.out.println("how mutch the time want to allocate the materiel ");
                Scanner scanner = new Scanner(System.in);
                String time = scanner.next();
                new Thread(() -> {
                    try {
                        TimeUnit.SECONDS.sleep(
                                Long.parseLong(time));
                        System.out.println("the Materiel with name " + name + " allocate with seccess");
                        System.out.println("time"+ time);
                        dataSource.materiels.add(materielA);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }).start();

                break;
            }


        }
    }


}
