package com.ensa.gi4.Dao;

import com.ensa.gi4.modele.Materiel;

public interface MaterielDAO {

//les fonctions crud


    void listerMateriels();
    void ajouterMateriel(Materiel materiel);
    void supprimerMateriel( int id);




}
