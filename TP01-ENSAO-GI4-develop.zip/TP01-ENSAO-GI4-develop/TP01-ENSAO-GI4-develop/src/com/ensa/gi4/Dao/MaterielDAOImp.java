package com.ensa.gi4.Dao;

import com.ensa.gi4.datatabase.DataSource;
import com.ensa.gi4.modele.Materiel;
import org.springframework.beans.factory.annotation.Autowired;

public class MaterielDAOImp implements MaterielDAO{


    DataSource dataSource;
    void setDataSource(DataSource dataSource){


        this.dataSource=dataSource;
    }
    @Override
    public void listerMateriels() {
        dataSource.getMaterial();

    }

    @Override
    public void ajouterMateriel(Materiel materiel) {

    }

    @Override
    public void supprimerMateriel(int id) {


    }
}
